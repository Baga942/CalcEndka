
package main

import (
	"bufio"
	"fmt"
	"net"
	"strconv"
)

func main() {
	client, err := net.Listen("tcp", ":8080")

	if err != nil {
		fmt.Println(err)
		return
	}

	for {

		connection, err := client.Accept()
		if err != nil {
			fmt.Println(err)
			return
		}
		for {
			receive, err := bufio.NewReader(connection).ReadString('.')
			if err != nil {
				fmt.Println(err)
				break
			}

			ans := calculate(receive)
			fmt.Println(receive + " = " + strconv.Itoa(ans))

			if receive == "quit" {
				break
			}

			_, err = connection.Write([]byte(strconv.Itoa(ans) + "\n"))
			if err != nil {
				fmt.Println(err)
				break
			}
		}
		connection.Close()

	}

}

func calculate(n string) int {
	text := n
	if len(n) > 0 && n[len(n)-1] == '\n' {
		text = n[0 : len(n)-1]
	}
	argis := []int{}
	j := 0
	for i := 0; i < len(text); i++ {
		if text[i] == '+' {
			s := text[j:i]
			if j != 0 {
				d := text[j-1 : j]
				s = d + s
			}

			j = i + 1
			if j > len(text) {
				break
			}
			p, _ := strconv.Atoi(s)
			argis = append(argis, p)
		}
		if text[i] == '-' {
			s := text[j:i]
			if j != 0 {
				d := text[j-1 : j]
				s = d + s
			}
			d := text[j:j]
			s = d + s
			j = i + 1
			if j > len(text) {
				break
			}
			p, _ := strconv.Atoi(s)
			argis = append(argis, p)
		}
	}
	if j < len(text) {
		s := text[j : len(text)-1]
		if j != 0 {
			d := text[j-1 : j]
			s = d + s
		}
		p, _ := strconv.Atoi(s)
		argis = append(argis, p)
		//fmt.Println("--",p)
	}

	sum := 0
	for i := 0; i < len(argis); i++ {
		sum += argis[i]
	}
	return sum
}
