package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
)

func main() {
	connection, err := net.Dial("tcp", "127.0.0.1:8080")
	if err != nil {
		fmt.Println(err)
		return
	}
	for {
		fmt.Println("Enter:")
		argument := readData()

		for i := 0; i < len(argument); i++ {
			nums := argument[i]

			if nums == "quit\n" {
				fmt.Println("suicide")
				break
			}

			write := nums + "."

			_, err = connection.Write([]byte(write))
			if err != nil {
				fmt.Println(err)
			}

			res, _ := bufio.NewReader(connection).ReadString('\n')

			fmt.Println("Result:", res)
		}
	}
	_, err = connection.Write([]byte("quit"))
	connection.Close()
	return

}

func readData() []string {
	reader := bufio.NewReader(os.Stdin)
	text, _ := reader.ReadString('\n')

	argument := []string{}
	j := 0
	for i := 0; i < len(text); i++ {
		if text[i] == ' ' {
			s := text[j:i]
			j = i + 1
			if j > len(text) {
				break
			}
			argument = append(argument, s)
		}
	}
	if j < len(text) {
		s := text[j : len(text)-1]
		argument = append(argument, s)
	}

	return argument
}